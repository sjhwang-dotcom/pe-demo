window.sourcingData = [
    {
        "name": "Apex Climate Services",
        "sponsor": "Founder",
        "source": "Grata",
        "r": "$42M",
        "e": "$6.5M",
        "m": "15.5%",
        "score": 96,
        "action": "Sign NDA",
        "lead": "David Kim"
    },
    {
        "name": "FlowTech Plumbing",
        "sponsor": "Broker",
        "source": "Inbound",
        "r": "$28M",
        "e": "$4.8M",
        "m": "17.1%",
        "score": 92,
        "action": "Review CIP",
        "lead": "Sarah Chen"
    },
    {
        "name": "SunState HVAC",
        "sponsor": "PPM",
        "source": "Pitchbook",
        "r": "$55M",
        "e": "$8.2M",
        "m": "14.9%",
        "score": 89,
        "action": "Contact",
        "lead": null
    },
    {
        "name": "CoolBreeze Inc",
        "sponsor": "Founder",
        "source": "Grata",
        "r": "$18M",
        "e": "$3.1M",
        "m": "17.2%",
        "score": 85,
        "action": "Pass",
        "lead": "Mike Ross"
    },
    {
        "name": "Midwest Mechanical",
        "sponsor": "Audax",
        "source": "Banker",
        "r": "$120M",
        "e": "$15.0M",
        "m": "12.5%",
        "score": 82,
        "action": "Monitor",
        "lead": null
    },
    {
        "name": "Reliable Air",
        "sponsor": "Founder",
        "source": "LinkedIn",
        "r": "$12M",
        "e": "$2.5M",
        "m": "20.8%",
        "score": 78,
        "action": "Review",
        "lead": "David Kim"
    },
    {
        "name": "Texas Thermal",
        "sponsor": "Founder",
        "source": "Grata",
        "r": "$35M",
        "e": "$5.5M",
        "m": "15.7%",
        "score": 75,
        "action": "Contact",
        "lead": "Sarah Chen"
    }
]